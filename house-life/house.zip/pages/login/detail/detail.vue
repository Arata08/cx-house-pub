<template>
	<view>
		<web-view src="https://uniapp.dcloud.net.cn/component/rich-text.html"></web-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
