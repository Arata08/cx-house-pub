<script>
	// 只能在App.vue里监听应用的生命周期
	export default {
		onLaunch: function(options) {
		},
		onShow: function(options) {
		},
		onHide: function() {
		}
	}
</script>


<style lang="scss">
	@import "uview-ui/index.scss";
	/*每个页面公共css */
</style>
