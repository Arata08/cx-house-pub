// 配置后端路径请修改config.js
// module.exports = {
//   publicPath: './',
//   devServer: {
//     proxy: {
//       '/api': {
// 		target: 'https://sourcebyte.vip',
//         changeOrigin: true,
//         pathRewrite: {
//           '^/api': '/api'
//         }
//       }
//     }
//   }
// }