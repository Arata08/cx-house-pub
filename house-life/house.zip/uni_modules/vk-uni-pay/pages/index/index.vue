<template>
  <view>请直接看示例项目的pages/index/index示例</view>
</template>

<script>
export default {
  data() {
    return {};
  },
  onLoad(options = {}) {},
  methods: {}
};
</script>
<style lang="scss" scoped></style>
