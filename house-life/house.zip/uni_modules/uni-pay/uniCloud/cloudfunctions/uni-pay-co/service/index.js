const pay = require("./pay");

module.exports = {
	pay
};
