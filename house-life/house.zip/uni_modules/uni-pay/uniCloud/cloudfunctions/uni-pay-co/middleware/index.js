const accessControl = require("./access-control");
const auth = require("./auth");

module.exports = {
	accessControl,
	auth
}
