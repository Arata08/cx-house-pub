const uniPayOrders = require("./uniPayOrders");
const uniIdUsers = require("./uniIdUsers");
const opendbOpenData = require("./opendbOpenData");
module.exports = {
	uniPayOrders,
	uniIdUsers,
	opendbOpenData
};
